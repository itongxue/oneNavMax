## 简介

该项目是一个导航主题，不能直接使用，需先到[LyLme_Spage](https://gitee.com/LyLme/lylme_spage)下载安装60导航框架。然后再将本主题文件（oneNavMax）上传到60导航的template目录【例如：nav.ifree6.cn/template】，最后在60导航后台启用本主题即可。

## 截图

**PC端截图【前端】**

![navmax202412-1](https://github.com/user-attachments/assets/205f186b-36f7-405f-a3b8-ad004cc55194)

**PC端截图【后台】**

![onenavmax202412-1](https://github.com/user-attachments/assets/432517e0-3913-4eeb-9a29-5e31a6a85147)


## 友情链接

我的个人博客：[艾自由网](https://www.ifree6.cn) 

我的导航网站：[小艾导航](https://nav.ifree6.cn)


## 更新日志

2024-12-30：

1. 优化首页搜索框，切换搜索引擎按钮更优雅；
2. 调整首页布局宽度，初步适配电脑、平板、手机不同设备宽度的显示样式；增加“一键滚到底部”按钮；
3. 优化后台界面；简化“添加链接”功能，填写链接信息后，点击添加后无需2次确认即可添加链接；
4. 修复部分登录的bug；
5. 更新PC端前端、后台截图。

2024-9-4：
1.优化后台链接、分类保存时的操作方式，点击保存后将自动返回链接/分类列表（采用JS控制）。
2.优化前端外观，可分别设置首页、收录页、登录页的背景图，前者在‘后台>网站配置>网站基本设置’中即可修改，而后两者需自行修改‘apply/index.php’和‘admin/login.php’文件中的图片地址。

